import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Code, BookOpen, Terminal, Globe } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Documentation() {
  const apiUrl = window.location.origin;

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <BookOpen className="h-8 w-8" />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">API Documentation</h1>
            <p className="text-muted-foreground mt-1">
              Learn how to integrate WhatsApp messaging into your applications
            </p>
          </div>
        </div>

        <Alert>
          <Globe className="h-4 w-4" />
          <AlertDescription>
            <strong>API Base URL:</strong> <code className="bg-muted px-2 py-1 rounded text-sm ml-2">{apiUrl}</code>
          </AlertDescription>
        </Alert>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="authentication">Authentication</TabsTrigger>
            <TabsTrigger value="endpoints">Endpoints</TabsTrigger>
            <TabsTrigger value="examples">Examples</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Getting Started</CardTitle>
                <CardDescription>Quick introduction to the WhatsApp API</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">What is this API?</h3>
                  <p className="text-sm text-muted-foreground">
                    This API allows you to send WhatsApp messages programmatically to any phone number. 
                    It's built on top of whatsapp-web.js and provides a simple REST interface for integration.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Quick Steps</h3>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground">
                    <li>Create an API key from the API Keys page</li>
                    <li>Make sure WhatsApp is connected (scan QR code if needed)</li>
                    <li>Use your API key to authenticate requests</li>
                    <li>Send messages via the /api/send endpoint</li>
                  </ol>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="authentication" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>API Key Authentication</CardTitle>
                <CardDescription>How to authenticate your API requests</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Authentication Method</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    All API requests require authentication using an API key. Include your API key in the request headers:
                  </p>
                  <div className="bg-muted p-4 rounded-lg">
                    <code className="text-sm">X-API-Key: wapi_your_api_key_here</code>
                  </div>
                </div>

                <Alert>
                  <AlertDescription className="space-y-2">
                    <p className="font-semibold">Security Best Practices:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm ml-4">
                      <li>Never expose your API keys in client-side code</li>
                      <li>Use environment variables to store API keys</li>
                      <li>Rotate your API keys regularly</li>
                      <li>Disable or delete unused API keys</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="endpoints" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Badge variant="default">POST</Badge>
                  /api/send
                </CardTitle>
                <CardDescription>Send a WhatsApp message</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2">Request Headers</h4>
                  <div className="bg-muted p-4 rounded-lg space-y-1">
                    <code className="text-sm block">Content-Type: application/json</code>
                    <code className="text-sm block">X-API-Key: wapi_your_api_key_here</code>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-sm mb-2">Request Body</h4>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">{`{
  "number": "201234567890",
  "message": "Hello from WhatsApp API!"
}`}</pre>
                  </div>
                  <div className="mt-2 space-y-1 text-sm text-muted-foreground">
                    <p><strong>number</strong>: Phone number with country code (without + or spaces)</p>
                    <p><strong>message</strong>: Message text (max 4096 characters)</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-sm mb-2">Success Response (200)</h4>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">{`{
  "success": true,
  "message": "Message sent successfully!",
  "messageId": "ABC123XYZ"
}`}</pre>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-sm mb-2">Error Response (400/401/500)</h4>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">{`{
  "success": false,
  "error": "Error message here"
}`}</pre>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Badge variant="secondary">GET</Badge>
                  /api/status
                </CardTitle>
                <CardDescription>Check WhatsApp connection status</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-4">
                    This endpoint doesn't require authentication and returns the current WhatsApp connection status.
                  </p>
                  <h4 className="font-semibold text-sm mb-2">Response (200)</h4>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">{`{
  "ready": true,
  "qrCode": null,
  "message": "WhatsApp is connected and ready to send messages"
}`}</pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="examples" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="h-5 w-5" />
                  cURL Example
                </CardTitle>
                <CardDescription>Send a message using cURL</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-muted p-4 rounded-lg">
                  <pre className="text-sm overflow-x-auto">{`curl -X POST ${apiUrl}/api/send \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: wapi_your_api_key_here" \\
  -d '{
    "number": "201234567890",
    "message": "Hello from cURL!"
  }'`}</pre>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  JavaScript / Node.js Example
                </CardTitle>
                <CardDescription>Send a message using fetch API</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-muted p-4 rounded-lg">
                  <pre className="text-sm overflow-x-auto">{`const apiKey = 'wapi_your_api_key_here';
const apiUrl = '${apiUrl}';

async function sendWhatsAppMessage(number, message) {
  const response = await fetch(\`\${apiUrl}/api/send\`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': apiKey
    },
    body: JSON.stringify({ number, message })
  });

  const data = await response.json();
  
  if (data.success) {
    console.log('Message sent!', data.messageId);
  } else {
    console.error('Error:', data.error);
  }
}

// Usage
sendWhatsAppMessage('201234567890', 'Hello from JavaScript!');`}</pre>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Python Example
                </CardTitle>
                <CardDescription>Send a message using Python requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-muted p-4 rounded-lg">
                  <pre className="text-sm overflow-x-auto">{`import requests

api_key = 'wapi_your_api_key_here'
api_url = '${apiUrl}'

def send_whatsapp_message(number, message):
    headers = {
        'Content-Type': 'application/json',
        'X-API-Key': api_key
    }
    
    data = {
        'number': number,
        'message': message
    }
    
    response = requests.post(
        f'{api_url}/api/send',
        headers=headers,
        json=data
    )
    
    result = response.json()
    
    if result.get('success'):
        print(f"Message sent! ID: {result.get('messageId')}")
    else:
        print(f"Error: {result.get('error')}")

# Usage
send_whatsapp_message('201234567890', 'Hello from Python!')`}</pre>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  PHP Example
                </CardTitle>
                <CardDescription>Send a message using PHP</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-muted p-4 rounded-lg">
                  <pre className="text-sm overflow-x-auto">{`<?php

$apiKey = 'wapi_your_api_key_here';
$apiUrl = '${apiUrl}';

function sendWhatsAppMessage($number, $message) {
    global $apiKey, $apiUrl;
    
    $data = array(
        'number' => $number,
        'message' => $message
    );
    
    $ch = curl_init("$apiUrl/api/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        "X-API-Key: $apiKey"
    ));
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    
    if ($result['success']) {
        echo "Message sent! ID: " . $result['messageId'];
    } else {
        echo "Error: " . $result['error'];
    }
}

// Usage
sendWhatsAppMessage('201234567890', 'Hello from PHP!');

?>`}</pre>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
